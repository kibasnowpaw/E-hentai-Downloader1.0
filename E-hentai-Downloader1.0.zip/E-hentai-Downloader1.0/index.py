import os
import requests
import json
from bs4 import BeautifulSoup
import time

API_URL = "https://api.e-hentai.org/api.php"
HEADERS = {
    "User-Agent": "Mozilla/5.0"
}

def fetch_gallery_metadata(gid, token):
    payload = {
        "method": "gdata",
        "gidlist": [[gid, token]],
        "namespace": 1
    }
    response = requests.post(API_URL, headers=HEADERS, json=payload)
    return response.json()

def download_gallery_images(gid, token, title):
    base_url = f"https://e-hentai.org/g/{gid}/{token}"
    response = requests.get(base_url, headers=HEADERS)
    response.raise_for_status()

    # Extract all image page URLs
    soup = BeautifulSoup(response.text, 'html.parser')
    image_page_elements = soup.find_all('div', class_='gdtm')
    image_page_urls = [elem.a['href'] for elem in image_page_elements]

    for page_url in image_page_urls:
        response = requests.get(page_url, headers=HEADERS)
        response.raise_for_status()

        # Extract image URL
        soup = BeautifulSoup(response.text, 'html.parser')
        img_element = soup.find('img', id='img')
        
        if img_element is None:
            print(f"Couldn't find image on page {page_url}. Skipping...")
            continue

        img_url = img_element['src']

        # Check if the image already exists
        img_name = os.path.basename(img_url)
        img_path = f"downloads/{title}/{img_name}"
        if os.path.exists(img_path):
            print(f"{img_name} already exists. Skipping...")
            continue

        # Download the image
        img_response = requests.get(img_url, stream=True, headers=HEADERS)
        img_response.raise_for_status()

        # Save the image
        if not img_name.lower().endswith(".zip"):  # Ignore zip files
            with open(img_path, 'wb') as img_file:
                for chunk in img_response.iter_content(chunk_size=8192):
                    img_file.write(chunk)
            print(f"Downloaded {img_name} from gallery {title}")

            # Create .nfo file for the image
            with open(f"{img_path}.nfo", 'w', encoding="utf-8") as nfo_file:
                nfo_file.write(f"Image Name: {img_name}\n")
                nfo_file.write(f"Gallery: {title}\n")
                nfo_file.write(f"URL: {img_url}\n")

        # Respectful delay to avoid hammering the server
        time.sleep(2)

if __name__ == "__main__":
    # Read gallery IDs and tokens from file
    with open("gallery_ids.txt", "r") as f:
        for line in f.readlines():
            gid, token = line.strip().split(',')
            metadata = fetch_gallery_metadata(gid, token)
            title = metadata['gmetadata'][0]['title']
            print(f"Fetching images for: {title}")
            
            # Create directory for downloads
            os.makedirs(f"downloads/{title}", exist_ok=True)

            download_gallery_images(gid, token, title)
